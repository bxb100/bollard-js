Build for test
